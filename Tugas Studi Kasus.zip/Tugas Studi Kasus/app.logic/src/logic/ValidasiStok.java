package logic;

import data.Buku;

public class ValidasiStok {
    public boolean cekStok(Buku buku, int jumlahBeli) {
        return jumlahBeli > 0 && jumlahBeli <= buku.stok();
    }
}