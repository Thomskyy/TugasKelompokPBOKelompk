package logic;

public class Diskon {
    public double hitungDiskon(double totalHarga) {
        // Lebih ringkas menggunakan operator ternary
        return totalHarga >= 150000 ? totalHarga * 0.10 : 0;
    }
}