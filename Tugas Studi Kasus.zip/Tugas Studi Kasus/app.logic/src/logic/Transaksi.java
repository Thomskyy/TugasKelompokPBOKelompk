package logic;

import data.Buku;
import data.Database;
import java.util.List;

public class Transaksi {

    // Fungsi baru untuk mengambil semua daftar buku untuk menu UI
    public List<Buku> ambilSemuaBuku() {
        return Database.getDataBuku();
    }

    // Mengambil satu buku berdasarkan pilihan angka dari user
    public Buku ambilBukuDariDatabase(int indeks) {
        List<Buku> daftar = Database.getDataBuku();
        if (indeks >= 0 && indeks < daftar.size()) {
            return daftar.get(indeks);
        }
        return null;
    }

    public double hitungTotal(Buku buku, int jumlahBeli) {
        return buku.harga() * jumlahBeli;
    }
}