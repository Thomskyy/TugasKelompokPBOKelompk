module app.logic {
    requires transitive app.data; // Jembatan agar app.ui bisa membaca tipe data Buku
    exports logic;
}