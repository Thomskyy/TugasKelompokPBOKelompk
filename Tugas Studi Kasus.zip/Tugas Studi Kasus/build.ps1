# Build script untuk proyek Toko Buku Digital (PowerShell)
$projectRoot = Get-Location

Write-Host "Membersihkan direktori output lama..." -ForegroundColor Cyan
if (Test-Path "bin") {
    Remove-Item -Recurse -Force bin
}
New-Item -ItemType Directory -Path "bin" | Out-Null

Write-Host "Mengompilasi semua modul..." -ForegroundColor Cyan
$dataFiles = Get-ChildItem -Path "app.data/src/data" -Filter "*.java" | % { $_.FullName }
$logicFiles = Get-ChildItem -Path "app.logic/src/logic" -Filter "*.java" | % { $_.FullName }
$uiFiles = Get-ChildItem -Path "app.ui/src/ui" -Filter "*.java" | % { $_.FullName }

$allFiles = @($dataFiles) + @($logicFiles) + @($uiFiles)

javac -d bin $allFiles

if ($LASTEXITCODE -eq 0) {
    Write-Host "Kompilasi berhasil!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Untuk menjalankan aplikasi, gunakan:" -ForegroundColor Yellow
    Write-Host "  java -cp bin ui.Main" -ForegroundColor White
    Write-Host ""
    Write-Host "Untuk input dari file:" -ForegroundColor Yellow
    Write-Host "  Get-Content input.txt | java -cp bin ui.Main" -ForegroundColor White
} else {
    Write-Host "Kompilasi gagal!" -ForegroundColor Red
    exit 1
}
