@echo off
REM Build script untuk proyek Toko Buku Digital
echo Membersihkan direktori output lama...
rmdir /s /q bin 2>nul
mkdir bin

echo Mengompilasi semua modul...
javac -d bin ^
    app.data/src/data/*.java ^
    app.logic/src/logic/*.java ^
    app.ui/src/ui/*.java

if %errorlevel% neq 0 (
    echo Kompilasi gagal!
    exit /b 1
)

echo Kompilasi berhasil!
echo.
echo Untuk menjalankan aplikasi, gunakan:
echo   java -cp bin ui.Main
pause
