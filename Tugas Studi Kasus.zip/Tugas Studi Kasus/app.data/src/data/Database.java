package data;

import java.util.List;

public class Database {
    // Menggunakan List.of()
    private static final List<Buku> DAFTAR_BUKU = List.of(
            new Buku("Pemrograman Java Dasar", 100000, 10),
            new Buku("Struktur Data dan Algoritma", 120000, 10),
            new Buku("Cara Jadi Orang Sukses", 150000, 0),
            new Buku("Pemrograman Berorientasi Objek", 135000, 1),
            new Buku("Belajar Jaringan Komputer", 140000, 10));

    public static List<Buku> getDataBuku() {
        return DAFTAR_BUKU;
    }
}