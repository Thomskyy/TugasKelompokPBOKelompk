package data;

// Record otomatis menyediakan getter .judul() dan .harga() secara implisit
public record Buku(String judul, double harga, int stok) {
}