module app.data {
    exports data; // Membuka package data agar bisa dibaca dari luar
}