package ui;

import data.Buku;
import logic.Diskon;
import logic.Transaksi;
import logic.ValidasiStok;
import java.util.List;
import java.util.Scanner;
import java.text.NumberFormat;
import java.util.Locale;

public class Main {
    public static void main(String[] args) {
        try (Scanner input = new Scanner(System.in)) {

            var validasi = new ValidasiStok();
            var transaksi = new Transaksi();
            var diskon = new Diskon();

            System.out.println("=== TOKO BUKU DIGITAL ===");
            System.out.println("Daftar Buku Yang Tersedia:");

            List<Buku> daftarBuku = transaksi.ambilSemuaBuku();
            for (int i = 0; i < daftarBuku.size(); i++) {
                Buku b = daftarBuku.get(i);
                // Menampilkan sisa stok di dalam menu daftar buku
                System.out.printf("%d. %s - %s [Stok: %d]%n",
                        (i + 1), b.judul(), formatRupiah(b.harga()), b.stok());
            }

            System.out.print("Pilih nomor buku (1-" + daftarBuku.size() + "): ");
            int pilihan = input.nextInt();

            Buku bukuTerpilih = transaksi.ambilBukuDariDatabase(pilihan - 1);

            if (bukuTerpilih == null) {
                System.out.println("Pilihan tidak valid! Transaksi dibatalkan.");
                return;
            }

            System.out.println("\nAnda memilih: " + bukuTerpilih.judul());
            System.out.print("Jumlah beli : ");
            int jumlah = input.nextInt();

            if (validasi.cekStok(bukuTerpilih, jumlah)) {
                double total = transaksi.hitungTotal(bukuTerpilih, jumlah);
                double potongan = diskon.hitungDiskon(total);
                double totalBayar = total - potongan;

                System.out.print("""
                        -------------------------
                        Total       : %s
                        Potongan    : %s
                        Total Bayar : %s
                        =========================
                        Transaksi Berhasil!
                        """.formatted(formatRupiah(total), formatRupiah(potongan), formatRupiah(totalBayar)));
            } else {
                // Pesan error diubah agar lebih informatif berdasarkan sisa stok asli
                System.out.printf("Transaksi Gagal! Jumlah beli tidak valid atau sisa stok hanya %d.%n",
                        bukuTerpilih.stok());
            }
        }
    }

    private static String formatRupiah(double nominal) {
        Locale lokalIndo = new Locale("id", "ID");
        NumberFormat formatter = NumberFormat.getCurrencyInstance(lokalIndo);
        return formatter.format(nominal).replace("Rp", "Rp ");
    }
}